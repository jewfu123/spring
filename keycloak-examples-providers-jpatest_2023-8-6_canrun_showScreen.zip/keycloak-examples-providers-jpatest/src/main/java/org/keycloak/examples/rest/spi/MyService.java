package org.keycloak.examples.rest.spi;

import java.util.List;

import org.keycloak.examples.rest.EventRepresentation;
import org.keycloak.provider.Provider;

public interface MyService extends Provider {

	List<Class<?>> getEntities();
	List<EventRepresentation> listCompanies();
	
	String getChangelogLocation();
	
	String getFactoryId();
}
