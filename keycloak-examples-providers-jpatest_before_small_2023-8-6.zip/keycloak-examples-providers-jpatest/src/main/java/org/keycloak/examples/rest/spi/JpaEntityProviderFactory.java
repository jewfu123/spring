package org.keycloak.examples.rest.spi;

import org.keycloak.provider.ProviderFactory;

public interface JpaEntityProviderFactory extends ProviderFactory<MyService> {
	
}
