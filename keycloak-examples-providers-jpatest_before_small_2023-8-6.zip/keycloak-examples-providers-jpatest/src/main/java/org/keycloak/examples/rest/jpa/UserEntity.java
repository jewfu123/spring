package org.keycloak.examples.rest.jpa;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@NamedQueries({
    @NamedQuery(name="getEventUserByUserid", query="SELECT * FROM EVENT_ENTITY AS a INNER JOIN USER_ENTITY AS b ON a.USER_ID = b.id WHERE a.USER_ID = :user_id"),
})
@Entity
public class UserEntity {

	@Id
	private String id;
	
	private String CLIENT_ID;
	private String DETAILS_JSON;
	private String ERROR;
	private String IP_ADDRESS;
	private String REALM_ID;
	private String SESSION_ID;
	private long EVENT_TIME;
	private String TYPE;
	private String USER_ID;

}

