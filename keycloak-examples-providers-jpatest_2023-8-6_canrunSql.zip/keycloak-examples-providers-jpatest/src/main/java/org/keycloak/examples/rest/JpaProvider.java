package org.keycloak.examples.rest;

import javax.persistence.EntityManager;



public class JpaProvider {

	//private final KeycloakSession session;
	//private final EntityManager em;
	private final int maxDetailLength = 100;
	
	//public JpaProvider()
}
