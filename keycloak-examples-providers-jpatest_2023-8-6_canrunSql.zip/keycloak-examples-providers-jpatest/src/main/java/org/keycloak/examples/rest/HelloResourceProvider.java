/*
 * Copyright 2016 Red Hat, Inc. and/or its affiliates
 * and other contributors as indicated by the @author tags.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.keycloak.examples.rest;

import org.keycloak.models.KeycloakSession;
import org.keycloak.services.resource.RealmResourceProvider;


import org.keycloak.examples.rest.jpa.EventEntity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;


/**
 * @author <a href="mailto:sthorger@redhat.com">Stian Thorgersen</a>
 */
public class HelloResourceProvider implements RealmResourceProvider {
	
	@PersistenceContext(unitName = "standalonePu")
    private EntityManager entityManager;
	
	//private JpaEventStoreProvider jes;
	private final EntityManager em;
	
    private KeycloakSession session;
    
    public HelloResourceProvider(KeycloakSession session, EntityManager em) {
    	System.out.println("HelloResourceProvider --- ");
        this.session = session;
        this.em = em;
        System.out.println("HelloResourceProvider --- session:" + session.toString());
        System.out.println("HelloResourceProvider --- em:" + em.toString());
//        jes = new JpaEventStoreProvider(session, em, 100);
//        System.out.println(jes);
    }
    
    public List<EventEntity> getList(EntityManager em) {
    	//FROM EVENT_ENTITY AS a INNER JOIN USER_ENTITY AS b ON a.USER_ID = b.id WHERE a.USER_ID='d564c863-d7a6-490d-9bae-072d89be5c68'
    	//select u from EventEntity u
    	//List events = em.createQuery("FROM EVENT_ENTITY AS a INNER JOIN USER_ENTITY AS b ON a.USER_ID = b.id WHERE a.USER_ID='d564c863-d7a6-490d-9bae-072d89be5c68'").getResultList();
    	List<EventEntity> events = em.createQuery("SELECT e FROM EventEntity e").getResultList();
    	//TypedQuery<EventEntity> query = em.createNamedQuery("findAll", EventEntity.class);
    	//List<EventEntity> result = query.getResultList();
    	if (events.isEmpty()) {
            System.out.println("could not find result: "); // + username
            return null;
        }
    	System.out.println(events.toString());
    	return events;
    	//return new UserAdapter(session, realm, model, result.get(0));
    	
    	//return events;
    }

    @Override
    public Object getResource() {
    	System.out.println("HelloResourceProvider --- getResource()");
        return this;
    }
    
    @GET
    @Path("/hello")
    @Produces("text/plain; charset=utf-8")
    public String getHello() {
    	System.out.println("------ HelloResourceProvider ---> getHello()");
    	this.getList(em);
        return "Hello ";
    }

    @GET
    @Produces("text/plain; charset=utf-8")
    public String get() {
        String name = session.getContext().getRealm().getDisplayName();
        if (name == null) {
            name = session.getContext().getRealm().getName();
        }
        this.getList(em);
        return "Hello " + name;
    }

    @Override
    public void close() {
    	System.out.println("------ HelloResourceProvider ---> close()");
    }

}
