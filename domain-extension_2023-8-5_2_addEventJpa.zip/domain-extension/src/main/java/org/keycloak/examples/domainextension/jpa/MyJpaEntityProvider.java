package org.keycloak.examples.domainextension.jpa;

import java.util.Map;

import javax.persistence.EntityManager;

import org.jboss.logging.Logger;
import org.keycloak.events.Event;
import org.keycloak.events.EventQuery;
import org.keycloak.events.EventStoreProvider;
import org.keycloak.events.admin.AdminEvent;
import org.keycloak.events.admin.AdminEventQuery;
import org.keycloak.events.jpa.JpaEventQuery;
import org.keycloak.events.jpa.JpaEventStoreProvider;
import org.keycloak.models.KeycloakSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MyJpaEntityProvider implements EventStoreProvider {

	private static final ObjectMapper mapper = new ObjectMapper();
    private static final TypeReference<Map<String, String>> mapType = new TypeReference<Map<String, String>>() {
    };
    private static final Logger logger = Logger.getLogger(MyJpaEntityProvider.class);

    private final KeycloakSession session;
    private final EntityManager em;
    private final int maxDetailLength;

    public MyJpaEntityProvider(KeycloakSession session, EntityManager em, int maxDetailLength) {
        this.session = session;
        this.em = em;
        this.maxDetailLength = maxDetailLength;
    }
    
	@Override
	public void onEvent(Event arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEvent(AdminEvent arg0, boolean arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clear() {
		em.createQuery("delete from EventEntity").executeUpdate();
		
	}

	@Override
	public void clear(String realmId) {
		em.createQuery("delete from EventEntity where realmId = :realmId").setParameter("realmId", realmId).executeUpdate();
		
	}

	@Override
	public void clear(String realmId, long olderThan) {
		em.createQuery("delete from EventEntity where realmId = :realmId and time < :time").setParameter("realmId", realmId).setParameter("time", olderThan).executeUpdate();
		
	}

	@Override
	public void clearAdmin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clearAdmin(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clearAdmin(String arg0, long arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clearExpiredEvents() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public AdminEventQuery createAdminQuery() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EventQuery createQuery() {
		return new JpaEventQuery(em);
	}



}
