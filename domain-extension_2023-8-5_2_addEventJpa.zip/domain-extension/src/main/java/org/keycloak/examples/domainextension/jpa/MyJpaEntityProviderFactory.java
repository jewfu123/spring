package org.keycloak.examples.domainextension.jpa;

import org.keycloak.Config;
import org.keycloak.connections.jpa.JpaConnectionProvider;
import org.keycloak.events.EventStoreProvider;
import org.keycloak.events.EventStoreProviderFactory;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;

public class MyJpaEntityProviderFactory implements EventStoreProviderFactory {
	
	public static final String ID = "myjpa";
    private int maxDetailLength;

    @Override
    public EventStoreProvider create(KeycloakSession session) {
        JpaConnectionProvider connection = session.getProvider(JpaConnectionProvider.class);
        return new MyJpaEntityProvider(session, connection.getEntityManager(), maxDetailLength);
    }

    @Override
    public void init(Config.Scope config) {
        maxDetailLength = config.getInt("max-detail-length", 0);
    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {

    }

    @Override
    public void close() {
    }

    @Override
    public String getId() {
        return ID;
    }

}
